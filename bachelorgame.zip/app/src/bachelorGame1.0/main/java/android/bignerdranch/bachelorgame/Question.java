package android.bignerdranch.bachelorgame;

import android.widget.TextView;

public class Question {
    private int qResId;
    private int aResId;

    public int getaResId() {
        return this.aResId;
    }

    public void setaResId(int aResId) {
        this.aResId = aResId;
    }

    private boolean ansTrue;
    private int qid;
    public String qText;
    private String aText;
    private String c1Text;
    private String c2Text;
    private String c3Text;
    private String c4Text;
    private Boolean chosen;

    public int getqResId() {
        return this.qResId;
    }

    public void setqResId(int qResId) {
        this.qResId = qResId;
    }

    public boolean isAnswerTrue(String s) {
        System.out.println(s);
        System.out.println(this.aText);
        if (s.equals(this.aText)) {
            return true;
        } else {
            return false;
        }
    }



    public void setAnswerTrue(boolean answerTrue) {
        ansTrue = answerTrue;
    }

    //constructor
    public Question(int qid, int q, int a, String[][] questionStrings, String[][]choices, int i, boolean b){
        qid = qid;
        chosen = b;
        qText = questionStrings[i][0];
        aText = questionStrings[i][1];
        c1Text = choices[i][0];
        c2Text = choices[i][1];
        c3Text = choices[i][2];
        c4Text = choices[i][3];
    }

    public String getqText(){
        return qText;
    }
    public int getQid(){
        return qid;
    }

    public void setQid(){
        this.qid = qid;
    }

    public String getC1Text() {
        return c1Text;
    }

    public void setC1Text(String c1Text) {
        this.c1Text = c1Text;
    }

    public String getC2Text() {
        return c2Text;
    }

    public void setC2Text(String c2Text) {
        this.c2Text = c2Text;
    }

    public String getC3Text() {
        return c3Text;
    }

    public void setC3Text(String c3Text) {
        this.c3Text = c3Text;
    }

    public String getC4Text() {
        return c4Text;
    }

    public void setC4Text(String c4Text) {
        this.c4Text = c4Text;
    }

    public Boolean getChosen() {
        return chosen;
    }

    public void setChosen(Boolean b) {
        this.chosen = b;
    }
}
