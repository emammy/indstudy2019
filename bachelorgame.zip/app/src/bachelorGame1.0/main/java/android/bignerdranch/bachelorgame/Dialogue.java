package android.bignerdranch.bachelorgame;

import android.widget.TextView;

public class Dialogue {

    private String dId;
    private String dType;
    private String dText;
    private String reaction;
//child dialogues
    private Dialogue next1;
    private Dialogue next2;

    public Dialogue(String di, String dtype, String dtext, String r, Dialogue n1, Dialogue n2) {
        dId = di;
        dType = dtype;
        dText = dtext;
        reaction = r;
        next1 = n1;
        next2 = n2;
    }


    public String getdId() {
        return dId;
    }

    public void setdId(String dId) {
        this.dId = dId;
    }

    public String getdType() {
        return dType;
    }

    public void setdType(String dType) {
        this.dType = dType;
    }

    public String getdText() {
        return dText;
    }

    public void setdText(String dText) {
        this.dText = dText;
    }

    public String getReaction() {
        return reaction;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }

    public Dialogue getNext1() {
        return next1;
    }

    public void setNext1(Dialogue next1) {
        this.next1 = next1;
    }

    public Dialogue getNext2() {
        return next2;
    }

    public void setNext2(Dialogue next2) {
        this.next2 = next2;
    }
}