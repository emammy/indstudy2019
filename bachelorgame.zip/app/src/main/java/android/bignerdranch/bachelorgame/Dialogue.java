package android.bignerdranch.bachelorgame;

public class Dialogue {
    //Dialogue objects act sort of like nodes, will point to the leading Dialogue & a following Dialogue
    //code should treat Dialogue depending on its Type


    private String dId;
    private String dType;
    //if it's a Question, the textviews, variables, etc. will be updated based on that
    //also, Dialogue.next will be the two answers attached to that question
    //on the other hand, if Type=Answer, Dialogue.next will just point to the followup question triggered by that answer
    private String dText;
    private String reaction;
    //Reactions to the players choice (for Answer type only, on questions this will be null)
    //Allows loading of unique reaction flavor text

    //child dialogues
    private Dialogue next1;
    private Dialogue next2;

    public Dialogue(String di, String dtype, String dtext, String r, Dialogue n1, Dialogue n2) {
        dId = di;
        dType = dtype;
        dText = dtext;
        reaction = r;
        next1 = n1;
        next2 = n2;
    }

//getters & setters
    public String getdId() { return dId; }

    public void setdId(String dId) {
        this.dId = dId;
    }

    public String getdType() {
        return dType;
    }

    public void setdType(String dType) {
        this.dType = dType;
    }

    public String getdText() { return dText; }

    public void setdText(String dText) {
        this.dText = dText;
    }

    public String getReaction() {
        return reaction;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }

    public Dialogue getNext1() {
        return next1;
    }

    public void setNext1(Dialogue next1) {
        this.next1 = next1;
    }

    public Dialogue getNext2() { return next2; }

    public void setNext2(Dialogue next2) {
        this.next2 = next2;
    }
}