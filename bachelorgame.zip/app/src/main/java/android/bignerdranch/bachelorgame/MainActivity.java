package android.bignerdranch.bachelorgame;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //instantiate buttons, etc. for later
    public Button choice1;
    public Button choice2;
    public Button restart;
    private Button start;
    private Button next;
    public Dialogue lastChosen;
    private boolean ans;
    //textviews
    public TextView mainText;
    private TextView welcomeText;
    public Dialogue current;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //title screen
        welcomeText = (TextView) findViewById(R.id.welcome_text);

        start = (Button) findViewById(R.id.start_button);
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startQuiz();
            }
        });
    }

    //once start button is pressed ->
    private void startQuiz() {
        welcomeText.findViewById(R.id.welcome_text).setVisibility(View.GONE);
        ans = false;

        //final Dialogue[] dialogues = new Dialogue [] {
        //new Dialogue(dId, dType, dText, reaction, next1, next2);
        Dialogue gameover = new Dialogue("gameover", "gameover", "gameover", null, null, null);
        Dialogue a63b = new Dialogue("a63b", "answer", getString(R.string.a63b), getString(R.string.a63b_reaction), gameover, gameover);
        Dialogue a63a = new Dialogue("a63a", "answer", getString(R.string.a63a), getString(R.string.a63a_reaction), gameover, gameover);
        Dialogue q63 = new Dialogue("q63", "question", getString(R.string.q63), null, a63a, a63b);
        Dialogue a62b = new Dialogue("a62b", "answer", getString(R.string.a62b), getString(R.string.a62b_reaction), gameover, gameover);
        Dialogue a62a = new Dialogue("a62a", "answer", getString(R.string.a62a), getString(R.string.a62a_reaction), gameover, gameover);
        Dialogue q62 = new Dialogue("q62", "question", getString(R.string.q62), null, a62a, a62b);
        Dialogue a61b = new Dialogue("a61b", "answer", getString(R.string.a61b), getString(R.string.a61b_reaction), q63, q63);
        Dialogue a61a = new Dialogue("a61a", "answer", getString(R.string.a61a), getString(R.string.a61a_reaction), q62, q62);
        Dialogue q61 = new Dialogue("q61", "question", getString(R.string.q61), null, a61a, a61b);
        //in update text display function, check whether it's answer or question
        Dialogue a53b = new Dialogue("a53b", "answer", getString(R.string.a53b), getString(R.string.a53b_reaction), gameover, gameover);
        Dialogue a53a = new Dialogue("a53a", "answer", getString(R.string.a53a), getString(R.string.a53a_reaction), q61, q61);
        Dialogue q53 = new Dialogue("q53", "question", getString(R.string.q53), null, a53a, a53b);
        Dialogue a52b = new Dialogue("a52b", "answer", getString(R.string.a52b), getString(R.string.a52b_reaction), gameover, gameover);
        Dialogue a52a = new Dialogue("a52a", "answer", getString(R.string.a52a), getString(R.string.a52a_reaction), q53, q53);
        Dialogue q52 = new Dialogue("q52", "question", getString(R.string.q52), null, a52a, a52b);
        Dialogue a51a = new Dialogue("a51a", "answer", getString(R.string.a51a), getString(R.string.a51a_reaction), gameover, gameover);
        Dialogue a51b = new Dialogue("a51b", "answer", getString(R.string.a51b), getString(R.string.a51b_reaction), q52, q52);
        Dialogue q51 = new Dialogue("q51", "question", getString(R.string.q51), null, a51a, a51b);
        Dialogue a43b = new Dialogue("a43b", "answer", getString(R.string.a43b), getString(R.string.a43b_reaction), q52, q52);
        Dialogue a43a = new Dialogue("a43a", "answer", getString(R.string.a43a), getString(R.string.a43a_reaction), q51, q51);
        Dialogue q43 = new Dialogue("q43", "question", getString(R.string.q43), null, a43a, a43b);
        Dialogue a42b = new Dialogue("a42b", "answer", getString(R.string.a42b), getString(R.string.a42b_reaction), gameover, gameover);
        Dialogue a42a = new Dialogue("a42a", "answer", getString(R.string.a42a), getString(R.string.a42a_reaction), q52, q52);
        Dialogue q42 = new Dialogue("q42", "question", getString(R.string.q42), null, a42a, a42b);
        Dialogue a32b = new Dialogue("a32b", "answer", getString(R.string.a32b), getString(R.string.a32b_reaction), q43, q43);
        Dialogue a32a = new Dialogue("a32a", "answer", getString(R.string.a32a), getString(R.string.a32a_reaction), q42, q42);
        Dialogue q32 = new Dialogue("q32", "question", getString(R.string.q32), null, a32a, a32b);
        Dialogue a41b = new Dialogue("a41b", "answer", getString(R.string.a41b), getString(R.string.a41b_reaction), q52, q52);
        Dialogue a41a = new Dialogue("a41a", "answer", getString(R.string.a41a), getString(R.string.a41a_reaction), q52, q52);
        Dialogue q41 = new Dialogue("q41", "question", getString(R.string.q41), null, a41a, a41b);
        Dialogue a31b = new Dialogue("a31b", "answer", getString(R.string.a31b), getString(R.string.a31b_reaction), q41, q41);
        Dialogue a31a = new Dialogue("a31a", "answer", getString(R.string.a31a), getString(R.string.a31a_reaction), q41, q41);
        Dialogue q31 = new Dialogue("q31", "question", getString(R.string.q31), null, a31a, a31b);
        Dialogue a22b = new Dialogue("a22b", "answer", getString(R.string.a22b), getString(R.string.a22b_reaction), q32, q32);
        Dialogue a22a = new Dialogue("a22a", "answer", getString(R.string.a22a), getString(R.string.a22a_reaction), q31, q31);
        Dialogue q22 = new Dialogue("q22", "question", getString(R.string.q22), null, a22a, a22b);
        Dialogue r21a_rose = new Dialogue("r21a_rose", "rose", getString(R.string.r21a_rose), null, q41, q41);
        Dialogue a21b = new Dialogue("a21b", "answer", getString(R.string.a21b), getString(R.string.a21b_reaction), gameover, gameover);
        Dialogue a21a = new Dialogue("a21a", "answer", getString(R.string.a21a), getString(R.string.a21a_reaction), q41, q41);
        Dialogue q21 = new Dialogue("q21", "question", getString(R.string.q21), null, a21a, a21b);
        Dialogue a11b = new Dialogue("a11b", "answer", getString(R.string.a11b), getString(R.string.a11b_reaction), q22, q22);
        Dialogue a11a = new Dialogue("a11a", "answer", getString(R.string.a11a), getString(R.string.a11a_reaction), q21, q21);
        Dialogue q11 = new Dialogue("q11", "question", getString(R.string.q11), getString(R.string.q11), a11a, a11b);


        //};

        final Question[] usedQuestions = new Question[]{

        };


        final Button[] buttons = new Button[4];
        //fill this w/ buttons as theyre instantiated
        //by doing this, we can ref buttons in an array (w/o using individual names)

        restart = (Button) findViewById(R.id.restart_button);
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mainText.setText(R.string.welcometext);
                restart.findViewById(R.id.restart_button).setVisibility(View.GONE);
                choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
                choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
                start.findViewById(R.id.start_button).setVisibility(View.VISIBLE);
                startQuiz();
            }
        });


        start.findViewById(R.id.start_button).setVisibility(View.GONE);

        next = (Button) findViewById(R.id.next_button);
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isGameOver(lastChosen);
                update(lastChosen);
            }
        });

        mainText = (TextView) findViewById(R.id.main_text_view);
        mainText.findViewById(R.id.main_text_view).setVisibility(View.VISIBLE);
        current = q11;







        //while (gameOver == false) {

        next.findViewById(R.id.next_button).setVisibility(View.GONE);
        mainText.setText(current.getdText());

        choice1 = (Button) findViewById(R.id.choice1_button);
        choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
        choice1.setText(current.getNext1().getdText().toString());
        choice1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                lastChosen = current.getNext1();
                reaction(lastChosen);
                //update(lastChosen);
            }
        });

        choice2 = (Button) findViewById(R.id.choice2_button);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
        choice2.setText(current.getNext2().getdText().toString());
        choice2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                lastChosen = current.getNext2();
                reaction(lastChosen);
                //update(lastChosen);
            }
        });

        /*
            next = (Button) findViewById(R.id.next_button);
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updateQuestion(lastChosen);
                }
            });
        */
        //end the game if it's over
        if(current.getNext1().getdText()=="gameover"){
            endGame();
        }
        //} //whle gameover=false
    }


    private void reaction(Dialogue lastChosen){
        choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
        mainText.setText(lastChosen.getReaction());
//        current = lastChosen;
    }

    private void update(Dialogue lastChosen) {
        if(lastChosen.getdText()!="gameover") {
            if (lastChosen.getNext1().getdText() != "gameover") {
                if (lastChosen.getNext2().getdText() != "gameover") {
                    lastChosen = lastChosen.getNext1(); //update lastChosen to the next Question
                    mainText.setText(lastChosen.getdText());
                    choice1.setText(lastChosen.getNext1().getdText());
                    choice2.setText(lastChosen.getNext2().getdText());
                    choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
                    choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
                    next.findViewById(R.id.next_button).setVisibility(View.GONE);

                    current = lastChosen;
                }
            }
        }
        else{
            isGameOver(lastChosen);
        }
    }

    private boolean checkAnswer(String userAns, Question currentQ) {

        return ans;
    }


    private void clearButtons(Button choice1, Button choice2){ //makes all buttons except selected gone
        choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
    }

    private void replaceButtons(Button choice1, Button choice2){ //reloads all buttons
        choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
    }


    private void isGameOver(Dialogue lastChosen){
        if(lastChosen.getdType()=="answer") {
            if (lastChosen.getNext1().getdText() == "gameover") {
                choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
                choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
                next.findViewById(R.id.next_button).setVisibility(View.GONE);
                restart.findViewById(R.id.restart_button).setVisibility(View.VISIBLE);
                mainText.setText("You lose! You got sent home! Chad is off frolicking with another girl :(");
            }
        }
    }
    private void colorReset(){ //resets color on all buttons (from red/green)
        choice1.findViewById(R.id.choice1_button).setBackgroundResource(R.drawable.btn3);//.setBackgroundColor(Color.parseColor("#D0D0D0"));
        choice2.findViewById(R.id.choice2_button).setBackgroundResource(R.drawable.btn3);
    }


    private void roseCeremony(Dialogue lastChosen){
        clearButtons(choice1, choice2);
        //put the following BEFORE this function is called in an if statement that checks whether the next event is a rose ceremony or not
        //mainText.setText("It's time for the rose ceremony. You're lined up with everyone and Chad is here. It's the moment of truth - will you get a rose?");
        if(lastChosen.getdType()=="answer") {
            if (lastChosen.getNext1().getdType()=="gameover"){
                endGame();
                //mainText.setText("Unfortunately, you didn't receive a rose...! Oh no!");
            }
            else{
                mainText.setText("You've received a rose from Chad! Congratulations!");
            }
        }
    }

    private void endGame(){
        clearButtons(choice1, choice2);
        next.findViewById(R.id.next_button).setVisibility(View.GONE);
        //have number input to clearButtons that decides WHICH buttons will be erased (same for replace)
        restart.findViewById(R.id.restart_button).setVisibility(View.VISIBLE);
        mainText.setText("game over");
    }
    /*
    private void endGame(String[][] questionStrings){ //loads the results screen.
      //  questionText.findViewById(R.id.main_text_view).setVisibility(View.GONE);

    }
    */
}
























/*





package android.bignerdranch.bachelorgame;


        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;
        import android.widget.Toast;
        import android.graphics.Color;
        import java.util.Random;
        import java.lang.Math;
        import java.util.Stack;

public class MainActivity extends AppCompatActivity {
    public Button choice1;
    public Button choice2;
    public Button restart;
    private Button start;
    private Button next;
    public Dialogue lastChosen;
    private boolean ans;
    public TextView mainText;
    private TextView welcomeText;
    private int answered = 0;
    public Dialogue current;
    public boolean gameOver;

    //private int questionNum = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //title screen
        welcomeText = (TextView) findViewById(R.id.welcome_text);

        start = (Button) findViewById(R.id.start_button);
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startQuiz();
            }
        });
    }

    //add question choices to question object (reference)

    private void startQuiz() {
        welcomeText.findViewById(R.id.welcome_text).setVisibility(View.GONE);
        ans = false;

//Dialogue objects
        //id refers to the original string resource name
        //type specifies what the program should do with this dialogue, how it should treat it, relevant functions to call
        //text shows what to display on the screen
        //reaction allows for the program to pull a "reaction" if needed via a separate function
        //next1 and next2 are pointers to the following dialogue that will show, allows the program to update this easily
        Dialogue gameover = new Dialogue("gameover", "gameover", "gameover", null, null, null);
        Dialogue a63b = new Dialogue("a63b", "answer", getString(R.string.a63b), getString(R.string.a63b_reaction), gameover, gameover);
        Dialogue a63a = new Dialogue("a63a", "answer", getString(R.string.a63a), getString(R.string.a63a_reaction), gameover, gameover);
        Dialogue q63 = new Dialogue("q63", "question", getString(R.string.q63), null, a63a, a63b);
        Dialogue a62b = new Dialogue("a62b", "answer", getString(R.string.a62b), getString(R.string.a62b_reaction), gameover, gameover);
        Dialogue a62a = new Dialogue("a62a", "answer", getString(R.string.a62a), getString(R.string.a62a_reaction), gameover, gameover);
        Dialogue q62 = new Dialogue("q62", "question", getString(R.string.q62), null, a62a, a62b);
        Dialogue a61b = new Dialogue("a61b", "answer", getString(R.string.a61b), getString(R.string.a61b_reaction), q63, q63);
        Dialogue a61a = new Dialogue("a61a", "answer", getString(R.string.a61a), getString(R.string.a61a_reaction), q62, q62);
        Dialogue q61 = new Dialogue("q61", "question", getString(R.string.q61), null, a61a, a61b);
        //in update text display function, check whether it's answer or question
        Dialogue a53b = new Dialogue("a53b", "answer", getString(R.string.a53b), getString(R.string.a53b_reaction), gameover, gameover);
        Dialogue a53a = new Dialogue("a53a", "answer", getString(R.string.a53a), getString(R.string.a53a_reaction), q61, q61);
        Dialogue q53 = new Dialogue("q53", "question", getString(R.string.q53), null, a53a, a53b);
        Dialogue a52b = new Dialogue("a52b", "answer", getString(R.string.a52b), getString(R.string.a52b_reaction), gameover, gameover);
        Dialogue a52a = new Dialogue("a52a", "answer", getString(R.string.a52a), getString(R.string.a52a_reaction), q53, q53);
        Dialogue q52 = new Dialogue("q52", "question", getString(R.string.q52), null, a52a, a52b);
        Dialogue r51b = new Dialogue("r51b", "rose", getString(R.string.r51b_rose), null, q52, q52);
        Dialogue r51a = new Dialogue("r51a", "rose", getString(R.string.r51a_rose), null, gameover, gameover);
        Dialogue a51a = new Dialogue("a51a", "answer", getString(R.string.a51a), getString(R.string.a51a_reaction), r51a, r51a);
        Dialogue a51b = new Dialogue("a51b", "answer", getString(R.string.a51b), getString(R.string.a51b_reaction), r51b, r51b);
        Dialogue q51 = new Dialogue("q51", "question", getString(R.string.q51), null, a51a, a51b);
        Dialogue r43a = new Dialogue("r43a", "rose", getString(R.string.r43a), null, q51, q51);
        Dialogue r43b = new Dialogue("r43b", "rose", getString(R.string.r43b), null, q52, q52);
        Dialogue a43b = new Dialogue("a43b", "answer", getString(R.string.a43b), getString(R.string.a43b_reaction), r43b, r43b);
        Dialogue a43a = new Dialogue("a43a", "answer", getString(R.string.a43a), getString(R.string.a43a_reaction), r43a, r43a);
        Dialogue q43 = new Dialogue("q43", "question", getString(R.string.q43), null, a43a, a43b);
        Dialogue r42a = new Dialogue("r42a", "rose", getString(R.string.r42a), null, q52, q52);
        Dialogue r42b = new Dialogue("r42b", "rose", getString(R.string.r42b), null, gameover, gameover);
        Dialogue a42b = new Dialogue("a42b", "answer", getString(R.string.a42b), getString(R.string.a42b_reaction), r42b, r42b);
        Dialogue a42a = new Dialogue("a42a", "answer", getString(R.string.a42a), getString(R.string.a42a_reaction), r42a, r42a);
        Dialogue q42 = new Dialogue("q42", "question", getString(R.string.q42), null, a42a, a42b);
        Dialogue a32b = new Dialogue("a32b", "answer", getString(R.string.a32b), getString(R.string.a32b_reaction), q43, q43);
        Dialogue a32a = new Dialogue("a32a", "answer", getString(R.string.a32a), getString(R.string.a32a_reaction), q42, q42);
        Dialogue q32 = new Dialogue("q32", "question", getString(R.string.q32), null, a32a, a32b);
        Dialogue r41 = new Dialogue("r41", "rose", getString(R.string.r41_rose), null, q52, q52);
        Dialogue a41b = new Dialogue("a41b", "answer", getString(R.string.a41b), getString(R.string.a41b_reaction), r41, r41);
        Dialogue a41a = new Dialogue("a41a", "answer", getString(R.string.a41a), getString(R.string.a41a_reaction), r41, r41);
        Dialogue q41 = new Dialogue("q41", "question", getString(R.string.q41), null, a41a, a41b);
        Dialogue a31b = new Dialogue("a31b", "answer", getString(R.string.a31b), getString(R.string.a31b_reaction), q41, q41);
        Dialogue a31a = new Dialogue("a31a", "answer", getString(R.string.a31a), getString(R.string.a31a_reaction), q41, q41);
        Dialogue q31 = new Dialogue("q31", "question", getString(R.string.q31), null, a31a, a31b);
        Dialogue r22a = new Dialogue("r22a_rose", "rose", getString(R.string.r22a_rose), null, q31, q31);
        Dialogue r22b = new Dialogue("r22b_rose", "rose", getString(R.string.r22b_rose), null, q32, q32);
        Dialogue a22b = new Dialogue("a22b", "answer", getString(R.string.a22b), getString(R.string.a22b_reaction), r22b, r22b);
        Dialogue a22a = new Dialogue("a22a", "answer", getString(R.string.a22a), getString(R.string.a22a_reaction), r22a, r22a);
        Dialogue q22 = new Dialogue("q22", "question", getString(R.string.q22), null, a22a, a22b);
        Dialogue r21b = new Dialogue("r21b_rose", "rose", getString(R.string.r21b_rose), null, gameover, gameover);
        Dialogue r21a = new Dialogue("r21a_rose", "rose", getString(R.string.r21a_rose), null, q41, q41);
        Dialogue a21b = new Dialogue("a21b", "answer", getString(R.string.a21b), getString(R.string.a21b_reaction), r21b, r21b);
        Dialogue a21a = new Dialogue("a21a", "answer", getString(R.string.a21a), getString(R.string.a21a_reaction), r21a, r21a);
        Dialogue q21 = new Dialogue("q21", "question", getString(R.string.q21), null, a21a, a21b);
        Dialogue a11b = new Dialogue("a11b", "answer", getString(R.string.a11b), getString(R.string.a11b_reaction), q22, q22);
        Dialogue a11a = new Dialogue("a11a", "answer", getString(R.string.a11a), getString(R.string.a11a_reaction), q21, q21);
        Dialogue q11 = new Dialogue("q11", "question", getString(R.string.q11), getString(R.string.q11), a11a, a11b);


        //};


        final Button[] buttons = new Button[4];
        //fill this w/ buttons as theyre instantiated
        //by doing this, we can ref buttons in an array (w/o using individual names)

        restart = (Button) findViewById(R.id.restart_button);
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mainText.setText(R.string.welcometext);
                restart.findViewById(R.id.restart_button).setVisibility(View.GONE);
                choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
                choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
                start.findViewById(R.id.start_button).setVisibility(View.VISIBLE);
                startQuiz();
            }
        });


        start.findViewById(R.id.start_button).setVisibility(View.GONE);

        next = (Button) findViewById(R.id.next_button);
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isGameOver(lastChosen);
                isRose(lastChosen);
                update(lastChosen);
            }
        });

        mainText = (TextView) findViewById(R.id.main_text_view);
        mainText.findViewById(R.id.main_text_view).setVisibility(View.VISIBLE);
        current = q11;







        //while (gameOver == false) {

        next.findViewById(R.id.next_button).setVisibility(View.GONE);
        mainText.setText(current.getdText());

        choice1 = (Button) findViewById(R.id.choice1_button);
        choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
        choice1.setText(current.getNext1().getdText().toString());
        choice1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                lastChosen = current.getNext1();
                reaction(lastChosen);
                //update(lastChosen);
            }
        });

        choice2 = (Button) findViewById(R.id.choice2_button);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
        choice2.setText(current.getNext2().getdText().toString());
        choice2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                lastChosen = current.getNext2();
                reaction(lastChosen);
                //update(lastChosen);
            }
        });

        /*
            next = (Button) findViewById(R.id.next_button);
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updateQuestion(lastChosen);
                }
            });
        */
//end the game if it's over
//deleteme        if(current.getNext1().getdText()=="gameover"){
//deleteme                endGame();
//deleteme                }
//deleteme                //} //whle gameover=false
//deleteme                }

/*deleteme
private void reaction(Dialogue lastChosen){
        choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
        mainText.setText(lastChosen.getReaction());
//        current = lastChosen;
        }

private void update(Dialogue lastChosen) {
        if(lastChosen.getdText()!="gameover" && lastChosen.getdType()!="rose") {
        if (lastChosen.getNext1().getdText() != "gameover") {
        if (lastChosen.getNext2().getdText() != "gameover") {
        lastChosen = lastChosen.getNext1(); //update lastChosen to the next Question
        mainText.setText(lastChosen.getdText());
        choice1.setText(lastChosen.getNext1().getdText());
        choice2.setText(lastChosen.getNext2().getdText());
        choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
        next.findViewById(R.id.next_button).setVisibility(View.GONE);

        current = lastChosen;
        }
        }
        }
        else if (lastChosen.getdText()=="gameover"){
        isGameOver(lastChosen);
        }
        else if(lastChosen.getdType()=="rose"){
        roseCeremony(lastChosen);
        }
        }

private boolean checkAnswer(String userAns, Question currentQ) {

        return ans;
        }


private void clearButtons(Button choice1, Button choice2){ //makes all buttons except selected gone
        choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
        }

private void replaceButtons(Button choice1, Button choice2){ //reloads all buttons
        choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
        }


private void isGameOver(Dialogue lastChosen){
        if(lastChosen.getdType()=="answer") {
        if (lastChosen.getNext1().getdText() == "gameover") {
        choice1.findViewById(R.id.choice1_button).setVisibility(View.GONE);
        choice2.findViewById(R.id.choice2_button).setVisibility(View.GONE);
        next.findViewById(R.id.next_button).setVisibility(View.GONE);
        restart.findViewById(R.id.restart_button).setVisibility(View.VISIBLE);
        mainText.setText("You lose! You got sent home! Chad is off frolicking with another girl :(");
        }
        }
        }

private void isRose(Dialogue lastChosen){
        if(lastChosen.getdType()=="rose"){
        roseCeremony(lastChosen);
        }
        }

private void colorReset(){ //resets color on all buttons (from red/green)
        choice1.findViewById(R.id.choice1_button).setBackgroundResource(R.drawable.btn3);//.setBackgroundColor(Color.parseColor("#D0D0D0"));
        choice2.findViewById(R.id.choice2_button).setBackgroundResource(R.drawable.btn3);
        }


private void roseCeremony(Dialogue lastChosen){
        clearButtons(choice1, choice2);
        next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
        mainText.setText(lastChosen.getdText());
        //put the following BEFORE this function is called in an if statement that checks whether the next event is a rose ceremony or not
        //mainText.setText("It's time for the rose ceremony. You're lined up with everyone and Chad is here. It's the moment of truth - will you get a rose?");

        }

private void endGame(){
        clearButtons(choice1, choice2);
        next.findViewById(R.id.next_button).setVisibility(View.GONE);
        //have number input to clearButtons that decides WHICH buttons will be erased (same for replace)
        restart.findViewById(R.id.restart_button).setVisibility(View.VISIBLE);
        mainText.setText("game over");
        }
    /*
    private void endGame(String[][] questionStrings){ //loads the results screen.
      //  questionText.findViewById(R.id.main_text_view).setVisibility(View.GONE);

    }
    */
//deleteme        }





//deleteme        */