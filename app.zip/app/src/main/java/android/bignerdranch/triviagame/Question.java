package android.bignerdranch.triviagame;

import android.widget.TextView;

public class Question {
    private int qResId;
    private int aResId;

    public int getaResId() {
        return this.aResId;
    }

    public void setaResId(int aResId) {
        this.aResId = aResId;
    }

    private boolean ansTrue;
    private String qText;
    private String aText;

    public int getqResId() {
        return this.qResId;
    }

    public void setqResId(int qResId) {
        this.qResId = qResId;
    }

    public boolean isAnswerTrue(String s) {
        System.out.println(s);
        System.out.println(this.aText);
        if (s.equals(this.aText)) {
            return true;
        } else {
            return false;
        }
    }

    public void setAnswerTrue(boolean answerTrue) {
        ansTrue = answerTrue;
    }

    //constructor
    public Question(int qid, int qResId, int aResId, String[][] questionStrings, int i){ //,boolean ansTrue){
        qid = qid;
        qResId = qResId;
        aResId = aResId;
        //set the strings for the question and answer.
        //question not really needed but
        //answer is needed to compare selected answer w actual answer.
        qText = questionStrings[i][0];
        aText = questionStrings[i][1];
        //ansTrue = ansTrue;
       // qText = qText;
        //aText = aText;
    }
}
