package android.bignerdranch.triviagame;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity {
    private Object player;
    private Button choice1;
    private Button choice2;
    private Button choice3;
    private Button choice4;
    private Button start;
    private Button next;
    private TextView questionText;
    private TextView choice1Text;
    private TextView choice2Text;
    private TextView choice3Text;
    private TextView choice4Text;
    private int score;
    private TextView welcomeText;

    private int q1id = R.string.q1_q;
    private int q2id = R.string.q2_q;

    private int qNum = 0; //used to add question strings to objects from string[][] array.

    private Question currentQ;

    //have array for the actual strings of questions & answers for verifying
    //array of question objects.


    private int questionNum = 0;
    private int messageResId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //title screen
        welcomeText = (TextView) findViewById(R.id.welcome_text);

        start = (Button) findViewById(R.id.start_button);
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //start  the quiz
                startQuiz();
            }
        });
        //startQuiz();
    }

        private void startQuiz(){
            welcomeText.findViewById(R.id.welcome_text).setVisibility(View.GONE);


            final String[][] questionStrings = new String[][]{
                    {getString(R.string.q1_q), getString(R.string.q1_a)},
                    {getString(R.string.q2_q), getString(R.string.q2_a)},
            };

            final Question[] questions = new Question[]{
                    new Question(1, R.string.q1_q, R.string.q1_a, questionStrings, 0),
                    new Question(2, R.string.q2_q, R.string.q2_a, questionStrings, 1),
            };

            start.findViewById(R.id.start_button).setVisibility(View.GONE);
            questionText = (TextView) findViewById(R.id.question_text_view);
            questionText.findViewById(R.id.question_text_view).setVisibility(View.VISIBLE);

            currentQ = questions[questionNum];


            choice1 = (Button) findViewById(R.id.choice1_button);
            choice1.findViewById(R.id.choice1_button).setVisibility(View.VISIBLE);
            choice1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    //compare answer on button to the question's real answer
                    checkAnswer(choice1.getText().toString(), questions[questionNum]);
                }
            });

            choice2 = (Button) findViewById(R.id.choice2_button);
            choice2.findViewById(R.id.choice2_button).setVisibility(View.VISIBLE);
            choice2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    checkAnswer(choice2.getText().toString(), questions[questionNum]);
                }
            });

            choice3 = (Button) findViewById(R.id.choice3_button);
            choice3.findViewById(R.id.choice3_button).setVisibility(View.VISIBLE);
            choice3.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    checkAnswer(choice3.getText().toString(), questions[questionNum]);
                }
            });

            choice4 = (Button) findViewById(R.id.choice4_button);
            choice4.findViewById(R.id.choice4_button).setVisibility(View.VISIBLE);
            choice4.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    checkAnswer(choice4.getText().toString(), questions[questionNum]);
                }
            });

            next = (Button) findViewById(R.id.next_button);
            next.findViewById(R.id.next_button).setVisibility(View.VISIBLE);
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //double check this line, idk 100% what it's doing
                    questionNum = (questionNum + 1) % questions.length;

                    updateQuestion(questionNum, questionStrings);
                    //add or deduct points?
                }
            });


            //updateQuestion();
        }
            private void updateQuestion(int i, String[][] questionStrings) {
                //int quest = currentQ.getqResId();
                //System.out.println(quest);
                //questionText.setText(quest);
                questionText.setText(questionStrings[i][0]);
                //swapping between answers. this needs to be changed because
                //it should be looping through smth, not just switching from 1 to 2.. inefficient
                if (i == 1) {
                    choice1.setText(R.string.q2_c1);
                    choice2.setText(R.string.q2_c2);
                    choice3.setText(R.string.q2_c3);
                    choice4.setText(R.string.q2_c4);
                } else {
                    choice1.setText(R.string.q1_c1);
                    choice2.setText(R.string.q1_c2);
                    choice3.setText(R.string.q1_c3);
                    choice4.setText(R.string.q1_c4);
                }

            }

            //adjust this for use with choices, not true/false
            private void checkAnswer(String userAns, Question currentQ) {
                //boolean ansTrue = questions[questionNum].isAnswerTrue();
                //int messageResId = 0;
                boolean ans = currentQ.isAnswerTrue(userAns);
                if (ans == true) {
                    messageResId = R.string.correct_toast;
                    score++;
                } else {
                    messageResId = R.string.incorrect_toast;
                }

                Toast.makeText(getApplicationContext(), messageResId, Toast.LENGTH_SHORT)
                        .show();
            }

    }

